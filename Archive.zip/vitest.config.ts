import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    exclude: ['**/node_modules/**', '**/.kilo/**', '**/dist/**'],
    include: ['tests/**/*.test.ts'],
  },
});
